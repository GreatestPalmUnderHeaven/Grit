from django.shortcuts import render, redirect
from django.views.generic.base import TemplateResponseMixin,View
from .forms import UserRegistrationForm, ProfileForm, Lesson_form, MessageForm, CommentsForm,LessonZert_form, LessonWork_form
from .models import Profile, Lesson, EnrollCource, Message,SRP, Comment,laboratorywork

class UserRegistrationView(TemplateResponseMixin, View):
    template_name = 'registration/registration.html'

    def get(self,request):
        registration_form = UserRegistrationForm()
        profile_form = ProfileForm()
        return self.render_to_response({'registration_form': registration_form, 'profile_form': profile_form})

    def post(self, request):
        registration_form = UserRegistrationForm(request.POST)
        profile_form = ProfileForm(request.POST, files=request.FILES)
        if registration_form.is_valid() and profile_form.is_valid():
            new_user = registration_form.save(commit=False)
        
            new_user.set_password(
            registration_form.cleaned_data['password'])
        
            new_user.save()
            profile = profile_form.save(commit = False)
            profile.user = new_user
            profile.save()
            return redirect('business:login')
        return self.render_to_response({'registration_form': registration_form, 'profile_form': profile_form})

class RedirectView(View):
    
    def get(self,request):
        if Profile.objects.filter(user= request.user,roles=2).exists():
            return redirect('business:StudentProfileIndexView')
        elif Profile.objects.filter(user= request.user,roles=1).exists():
            return redirect('business:TeacherView') 

class IndexView(TemplateResponseMixin,View):
    template_name = 'index.html'
    def get(self,request):
        profile = Profile.objects.all()
        return self.render_to_response({'profile': profile})

class TeacherView(TemplateResponseMixin,View):
    template_name = 'teacher/home.html'
    def get(self,request):
        profile = Profile.objects.get(user = request.user)
        return self.render_to_response({'profile': profile})


class LessonCreateView(TemplateResponseMixin,View):
    template_name = 'teacher/courses/form.html'

    def get(self,request):
        lesson_form = Lesson_form()
        return self.render_to_response({'lesson_form': lesson_form})
    
    def post(self,request):
        lesson_form = Lesson_form(request.POST, request.FILES)
        if lesson_form.is_valid():#тексеру
            courses_obj = lesson_form.save(commit=False)
            courses_obj.author = request.user
            courses_obj.save()
            return redirect('business:LessonView')
        return self.render_to_response({'lesson_form': lesson_form})

class LessonView(TemplateResponseMixin,View):
    template_name = 'teacher/courses/lesson.html'

    def get(self,request):
        search_text = request.GET.get('search_text', '')
        lesson = Lesson.objects.all().order_by('-id');
        if search_text:
            lesson = Lesson.objects.filter(title__icontains=search_text).order_by('-id')
        return self.render_to_response({'lesson': lesson, 'search_text': search_text})
        

class LessonDetailView(TemplateResponseMixin,View):
    template_name = 'teacher/courses/lesson-detail.html'
    def get(self,request, id):
        lesson = Lesson.objects.get(id=id)
        work = laboratorywork.objects.filter(lesson = id)
        srp = SRP.objects.filter(lesson = id)
        return self.render_to_response({'lesson': lesson, 'work':work,'srp':srp})


class StudentProfileIndexView(TemplateResponseMixin,View):
    template_name = 'student/home.html'
    def get(self,request):
        profile = Profile.objects.get(user = request.user)
        return self.render_to_response({'profile': profile})

class LessonsView(TemplateResponseMixin,View):
    template_name = 'student/lesson.html'
    def get(self,request):
        search_text = request.GET.get('search_text', '')
        lesson = Lesson.objects.all().order_by('-id');
        if search_text:
            lesson = Lesson.objects.filter(title__icontains=search_text).order_by('-id')
        return self.render_to_response({'lesson': lesson, 'search_text': search_text})

class MyLessonsView(TemplateResponseMixin,View):
    template_name = 'student/mylesson.html'
    def get(self,request):
        mylesson = EnrollCource.objects.filter(student = request.user).order_by('-id')
        return self.render_to_response({'mylesson': mylesson})

class MyLessonsDetailView(TemplateResponseMixin,View):
    template_name = 'student/mylesson-detail.html'
    def get(self,request, id):
        mylesson = EnrollCource.objects.get(id=id)
        return self.render_to_response({'mylesson': mylesson})

        
class LessonsDetailView(TemplateResponseMixin,View):
    template_name = 'student/lesson-detail.html'
    def get(self,request, id):
        lesson = Lesson.objects.get(id=id)
        coments = Comment.objects.filter(lesson=lesson)
        comment_form = CommentsForm()
        return self.render_to_response({'lesson': lesson, 'id':id,  'comment_form':comment_form,'coments':coments})

    def post(self,request, id):
        lesson = Lesson.objects.get(id=id)
        coments = Comment.objects.filter(lesson=lesson)
        comment_form = CommentsForm(request.POST)
        if comment_form.is_valid():
            obj_save = comment_form.save(commit=False)
            obj_save.lesson = lesson
            obj_save.save()
            return redirect('business:LessonsDetailView', id=id)
        return self.render_to_response({'lesson': lesson, 'id':id,  'comment_form':comment_form,'coments':coments})

