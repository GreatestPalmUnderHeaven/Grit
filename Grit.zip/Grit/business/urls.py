from django.urls import path
from .import views
from django.contrib.auth import views as auth_views
app_name = 'business'

urlpatterns =[
	path('login/',auth_views.LoginView.as_view(),name='login'),
	path('logout/',auth_views.LogoutView.as_view(),name='logout'),
	path('',views.IndexView.as_view(), name='IndexView'),
	path('redirect/',views.RedirectView.as_view(), name='RedirectView'),
	path('teacher/',views.TeacherView.as_view(), name='TeacherView'),
	path('teacher/lessonCreate',views.LessonCreateView.as_view(), name='LessonCreateView'),
	path('teacher/lessons',views.LessonView.as_view(), name='LessonView'),
	path('teacher/lessons/detail/<int:id>',views.LessonDetailView.as_view(), name='LessonDetailView'),
	path('student/',views.StudentProfileIndexView.as_view(), name='StudentProfileIndexView'),
	path('student/lessons',views.LessonsView.as_view(), name='LessonsView'),
	path('student/mylessons',views.MyLessonsView.as_view(), name='MyLessonsView'),
	path('student/lessons/detail/<int:id>',views.LessonsDetailView.as_view(), name='LessonsDetailView'),
	path('student/mylesson/mylessondetail/<int:id>',views.MyLessonsDetailView.as_view(), name='MyLessonsDetailView'),
	path('user/registration', views.UserRegistrationView.as_view(), name='user_registration_page'),
	
]